import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { AppDependencies, RequestLogger } from "./app.js";

const mocks = vi.hoisted(() => ({
  allocationFindFirst: vi.fn(),
  allocationCount: vi.fn(),
  allocationGroupBy: vi.fn(),
  courseCreate: vi.fn(),
  courseDelete: vi.fn(),
  courseServiceDelete: vi.fn(),
  courseFindMany: vi.fn(),
  courseUpdate: vi.fn(),
  createApp: vi.fn(),
  excuseCreate: vi.fn(),
  findAllocationCandidates: vi.fn(),
  getPublicHolidays: vi.fn(),
  getTutorHourSummary: vi.fn(),
  getTutorWorkloads: vi.fn(),
  listen: vi.fn(),
  profileCreate: vi.fn(),
  profileFindMany: vi.fn(),
  profileFindUnique: vi.fn(),
  organiserApplicationFindUnique: vi.fn(),
  queryRaw: vi.fn(),
  academicTermFindMany: vi.fn(),
  timeSlotFindFirst: vi.fn(),
  timeSlotCreate: vi.fn(),
  timeSlotUpdate: vi.fn(),
  timeSlotFindMany: vi.fn(),
  timesheetUpsert: vi.fn(),
  transaction: vi.fn(),
  tutorMarkFindMany: vi.fn(),
  tutorMarkDeleteMany: vi.fn(),
  tutorMarkUpsert: vi.fn(),
  tutorHourLimitDeleteMany: vi.fn(),
  workLogCreate: vi.fn(),
}));

vi.mock("dotenv/config", () => ({}));

vi.mock("./app.js", () => ({
  createApp: mocks.createApp,
  createRouteError(status: number, code: string, message: string) {
    return Object.assign(new Error(message), { status, code });
  },
}));

vi.mock("./database.js", () => ({
  prisma: {
    $transaction: mocks.transaction,
    $queryRaw: mocks.queryRaw,
    allocation: {
      count: mocks.allocationCount,
      findFirst: mocks.allocationFindFirst,
      groupBy: mocks.allocationGroupBy,
    },
    course: {
      create: mocks.courseCreate,
      delete: mocks.courseDelete,
      findMany: mocks.courseFindMany,
      update: mocks.courseUpdate,
    },
    profile: {
      create: mocks.profileCreate,
      findMany: mocks.profileFindMany,
      findUnique: mocks.profileFindUnique,
    },
    organiserApplication: {
      findUnique: mocks.organiserApplicationFindUnique,
    },
    excuse: {
      create: mocks.excuseCreate,
    },
    timeSlot: {
      create: mocks.timeSlotCreate,
      update: mocks.timeSlotUpdate,
      findMany: mocks.timeSlotFindMany,
    },
    tutorMark: {
      upsert: mocks.tutorMarkUpsert,
      deleteMany: mocks.tutorMarkDeleteMany,
      findMany: mocks.tutorMarkFindMany,
    },
    tutorHourLimit: {
      deleteMany: mocks.tutorHourLimitDeleteMany,
    },
  },
  queryClient: {},
}));

vi.mock("./services/allocation-queries.js", () => ({
  findAllocationCandidates: mocks.findAllocationCandidates,
  getTutorHourSummary: mocks.getTutorHourSummary,
  getTutorWorkloads: mocks.getTutorWorkloads,
}));

vi.mock("./services/course-service.js", () => ({
  createCourseService: () => ({ deleteCourse: mocks.courseServiceDelete }),
}));

vi.mock("./integrations/public-holidays.js", () => ({
  createSouthAfricaPublicHolidayService: () => ({
    execute: mocks.getPublicHolidays,
  }),
}));

const originalEnvironment = {
  AUTH0_AUDIENCE: process.env.AUTH0_AUDIENCE,
  AUTH0_CLIENT_ID: process.env.AUTH0_CLIENT_ID,
  AUTH0_DB_CONNECTION: process.env.AUTH0_DB_CONNECTION,
  AUTH0_DOMAIN: process.env.AUTH0_DOMAIN,
  AUTH0_MANAGEMENT_CLIENT_ID: process.env.AUTH0_MANAGEMENT_CLIENT_ID,
  AUTH0_MANAGEMENT_CLIENT_SECRET: process.env.AUTH0_MANAGEMENT_CLIENT_SECRET,
  AUTH0_ROLES_CLAIM: process.env.AUTH0_ROLES_CLAIM,
  FRONTEND_ORIGIN: process.env.FRONTEND_ORIGIN,
  PORT: process.env.PORT,
};

function restoreEnvironment() {
  for (const [name, value] of Object.entries(originalEnvironment)) {
    if (value === undefined) {
      delete process.env[name];
    } else {
      process.env[name] = value;
    }
  }
}

function capturedDependencies(): AppDependencies {
  return mocks.createApp.mock.calls[0]![1] as AppDependencies;
}

function capturedRequestLogger(): RequestLogger {
  return mocks.createApp.mock.calls[0]![2] as RequestLogger;
}

beforeEach(() => {
  vi.resetModules();
  for (const mock of Object.values(mocks)) {
    mock.mockReset();
  }

  mocks.createApp.mockReturnValue({
    listen: mocks.listen,
  });
  mocks.organiserApplicationFindUnique.mockResolvedValue(null);
  mocks.academicTermFindMany.mockResolvedValue([]);
  mocks.timeSlotFindMany.mockResolvedValue([]);
  mocks.timeSlotFindFirst.mockResolvedValue({ id: 8 });
  mocks.transaction.mockImplementation(
    async (callback: (transaction: unknown) => unknown) =>
      callback({
        academicTerm: { findMany: mocks.academicTermFindMany },
        timeSlot: { findMany: mocks.timeSlotFindMany, findFirst: mocks.timeSlotFindFirst, create: mocks.timeSlotCreate, update: mocks.timeSlotUpdate },
        timesheet: { upsert: mocks.timesheetUpsert },
        workLog: { create: mocks.workLogCreate },
      }),
  );
});

afterEach(() => {
  vi.restoreAllMocks();
  restoreEnvironment();
});

describe("server startup", () => {
  it("uses the default port and connects the Prisma readiness check", async () => {
    delete process.env.PORT;
    const consoleLog = vi
      .spyOn(console, "log")
      .mockImplementation(() => undefined);

    await import("./server.js");

    expect(mocks.createApp).toHaveBeenCalledOnce();

    const checkReadiness = mocks.createApp.mock.calls[0][0] as () => Promise<void>;
    await checkReadiness();

    expect(mocks.queryRaw).toHaveBeenCalledOnce();
    expect(mocks.listen).toHaveBeenCalledWith(3000, expect.any(Function));

    const onListening = mocks.listen.mock.calls[0][1] as () => void;
    onListening();

    expect(consoleLog).toHaveBeenCalledWith(
      "Tutor Mx API listening on http://localhost:3000",
    );
  });

  it("keeps every unconfigured Auth0 boundary fail-closed", async () => {
    delete process.env.AUTH0_DOMAIN;
    delete process.env.AUTH0_AUDIENCE;
    delete process.env.AUTH0_CLIENT_ID;
    delete process.env.AUTH0_DB_CONNECTION;
    delete process.env.AUTH0_MANAGEMENT_CLIENT_ID;
    delete process.env.AUTH0_MANAGEMENT_CLIENT_SECRET;

    await import("./server.js");
    const dependencies = capturedDependencies();

    await expect(dependencies.verifyAccessToken("token")).rejects.toThrow(
      "Auth0 access-token verification is not configured",
    );
    await expect(
      dependencies.requestPasswordReset("user@tutormx.example"),
    ).rejects.toThrow("Auth0 password reset is not configured");

    mocks.profileFindUnique.mockResolvedValueOnce(null);
    await expect(
      dependencies.onboardUser("auth0|new", "TUTOR"),
    ).rejects.toThrow("Auth0 Management API onboarding is not configured");

    mocks.profileFindUnique.mockResolvedValueOnce(null);
    await expect(dependencies.deleteAccount?.("auth0|new")).rejects.toThrow(
      "Auth0 Management API deletion is not configured",
    );
  });

  it("uses the configured PORT", async () => {
    process.env.PORT = "4100";
    const consoleLog = vi
      .spyOn(console, "log")
      .mockImplementation(() => undefined);

    await import("./server.js");

    expect(mocks.listen).toHaveBeenCalledWith(4100, expect.any(Function));

    const onListening = mocks.listen.mock.calls[0][1] as () => void;
    onListening();

    expect(consoleLog).toHaveBeenCalledWith(
      "Tutor Mx API listening on http://localhost:4100",
    );
  });

  it("wires the production public-holiday adapter into the Express dependencies", async () => {
    const result = {
      source: "external" as const,
      data: [],
      retrievedAt: "2026-09-12T10:00:00.000Z",
    };
    mocks.getPublicHolidays.mockResolvedValue(result);

    await import("./server.js");

    await expect(capturedDependencies().getPublicHolidays(2026)).resolves.toBe(
      result,
    );
    expect(mocks.getPublicHolidays).toHaveBeenCalledWith(2026);
  });

  it("passes configured Auth0, CORS and safe request logging dependencies", async () => {
    process.env.AUTH0_DOMAIN = "tenant.example.auth0.com";
    process.env.AUTH0_AUDIENCE = "https://api.tutormx.example";
    process.env.AUTH0_CLIENT_ID = "public-spa-client-id";
    process.env.AUTH0_DB_CONNECTION = "Username-Password-Authentication";
    process.env.FRONTEND_ORIGIN = "https://app.tutormx.example";
    const consoleInfo = vi
      .spyOn(console, "info")
      .mockImplementation(() => undefined);

    await import("./server.js");

    expect(capturedDependencies().corsOrigin).toBe(
      "https://app.tutormx.example",
    );
    expect(capturedDependencies().verifyAccessToken).toBeTypeOf("function");
    expect(capturedDependencies().requestPasswordReset).toBeTypeOf("function");

    capturedRequestLogger()({
      method: "PATCH",
      path: "/api/courses/1",
      status: 200,
      durationMs: 1.25,
    });
    expect(consoleInfo).toHaveBeenCalledWith(
      JSON.stringify({
        event: "http_request",
        method: "PATCH",
        path: "/api/courses/1",
        status: 200,
        durationMs: 1.25,
      }),
    );
  });
});

describe("server-side API persistence", () => {
  it("maps profile, course and tutor reads to safe summaries", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();

    mocks.profileFindUnique.mockResolvedValueOnce({
      id: 1,
      email: "organiser@tutormx.example",
      fullName: "Demo Organiser",
      role: "ORGANISER",
    });
    await expect(
      dependencies.findProfileByAuth0Id("demo|organiser"),
    ).resolves.toEqual({
      id: 1,
      email: "organiser@tutormx.example",
      fullName: "Demo Organiser",
      role: "ORGANISER",
    });
    expect(mocks.profileFindUnique).toHaveBeenCalledWith({
      where: { auth0Id: "demo|organiser" },
      select: { id: true, email: true, fullName: true, role: true },
    });

    mocks.profileFindUnique.mockResolvedValueOnce({
      id: 2,
      email: "unknown@tutormx.example",
      fullName: "Unknown Role",
      role: "OTHER",
    });
    await expect(
      dependencies.findProfileByAuth0Id("demo|unknown"),
    ).resolves.toBeNull();

    mocks.courseFindMany.mockResolvedValueOnce([
      { id: 3, code: "DEMO101", name: "Demo Course", internal: "discard" },
    ]);
    // A course with no rate or budget recorded reports them as unset, never 0.
    await expect(dependencies.listCourses()).resolves.toEqual([
      { id: 3, code: "DEMO101", name: "Demo Course", hourlyRate: null, budget: null },
    ]);

    mocks.profileFindMany.mockResolvedValueOnce([
      { id: 4, email: "tutor@tutormx.example", fullName: "Demo Tutor", role: "TUTOR" },
      { id: 5, email: "tutor2@tutormx.example", fullName: "Tutor Without Limit", role: "TUTOR" },
    ]);
    mocks.getTutorWorkloads.mockResolvedValueOnce([
      {
        tutorId: 4,
        weeklyLimit: 12.5,
        usedHours: 8,
        remainingHours: 4.5,
        workedHours: 6,
        weekStart: "2030-09-02T00:00:00.000Z",
        weekEnd: "2030-09-08T23:59:59.999Z",
        capacityStatus: "near-limit",
      },
      {
        tutorId: 5,
        weeklyLimit: null,
        usedHours: 0,
        remainingHours: null,
        workedHours: 0,
        weekStart: "2030-09-02T00:00:00.000Z",
        weekEnd: "2030-09-08T23:59:59.999Z",
        capacityStatus: "not-set",
      },
    ]);
    await expect(dependencies.listTutors()).resolves.toEqual([
      {
        id: 4,
        email: "tutor@tutormx.example",
        fullName: "Demo Tutor",
        role: "TUTOR",
        weeklyHours: 12.5,
        usedHours: 8,
        remainingHours: 4.5,
        workedHours: 6,
        weekStart: "2030-09-02T00:00:00.000Z",
        weekEnd: "2030-09-08T23:59:59.999Z",
        capacityStatus: "near-limit",
      },
      {
        id: 5,
        email: "tutor2@tutormx.example",
        fullName: "Tutor Without Limit",
        role: "TUTOR",
        weeklyHours: null,
        usedHours: 0,
        remainingHours: null,
        workedHours: 0,
        weekStart: "2030-09-02T00:00:00.000Z",
        weekEnd: "2030-09-08T23:59:59.999Z",
        capacityStatus: "not-set",
      },
    ]);
  });

  it("creates, updates and deletes courses through Prisma", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();

    mocks.courseCreate.mockResolvedValueOnce({
      id: 6,
      code: "NEW101",
      name: "New Course",
    });
    await expect(
      dependencies.createCourse({ code: "NEW101", name: "New Course" }),
    ).resolves.toEqual({
      id: 6,
      code: "NEW101",
      name: "New Course",
      hourlyRate: null,
      budget: null,
    });

    // Money fields are written when given, and come back as numbers.
    mocks.courseCreate.mockResolvedValueOnce({
      id: 7,
      code: "PAY101",
      name: "Paid Course",
      hourlyRate: "180.00",
      budget: "5000.00",
    });
    await expect(
      dependencies.createCourse({
        code: "PAY101",
        name: "Paid Course",
        hourlyRate: 180,
        budget: 5000,
      }),
    ).resolves.toEqual({
      id: 7,
      code: "PAY101",
      name: "Paid Course",
      hourlyRate: 180,
      budget: 5000,
    });
    expect(mocks.courseCreate.mock.calls[1]![0].data).toMatchObject({
      hourlyRate: 180,
      budget: 5000,
    });

    mocks.courseUpdate.mockResolvedValueOnce({
      id: 6,
      code: "NEW102",
      name: "Updated Course",
    });
    await expect(
      dependencies.updateCourse(6, {
        code: "NEW102",
        name: "Updated Course",
      }),
    ).resolves.toEqual({
      id: 6,
      code: "NEW102",
      name: "Updated Course",
      hourlyRate: null,
      budget: null,
    });

    mocks.courseServiceDelete.mockResolvedValueOnce(undefined);
    await expect(dependencies.deleteCourse(6)).resolves.toBeUndefined();
    expect(mocks.courseServiceDelete).toHaveBeenCalledWith(6);
  });

  it("builds the own-tutor dashboard from Prisma and the Member 6 hour query", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();
    mocks.profileFindUnique.mockResolvedValueOnce({
      id: 7,
      role: "TUTOR",
      allocations: [
        {
          id: 4,
          startsAt: new Date("2030-09-04T14:00:00.000Z"),
          endsAt: new Date("2030-09-04T16:00:00.000Z"),
          allocatedHours: "2.00",
          status: "CONFIRMED",
          course: { code: "DEMO101", name: "Demo Course" },
        },
      ],
    });
    mocks.getTutorHourSummary.mockResolvedValueOnce({
      tutorId: 7,
      weeklyLimit: 10,
      usedHours: 6,
      remainingHours: 4,
    });

    await expect(
      dependencies.getTutorDashboard("auth0|current-tutor"),
    ).resolves.toEqual({
      allocations: [
        {
          id: 4,
          courseCode: "DEMO101",
          courseName: "Demo Course",
          startsAt: "2030-09-04T14:00:00.000Z",
          endsAt: "2030-09-04T16:00:00.000Z",
          allocatedHours: 2,
          status: "CONFIRMED",
          occurrenceStatus: "SCHEDULED", absenceReason: null, excusePending: false, workLogEligible: true, excuse: null,
        },
      ],
      weeklyLimit: 10,
      usedHours: 6,
      remainingHours: 4,
    });
    expect(mocks.profileFindUnique).toHaveBeenCalledWith(
      expect.objectContaining({ where: { auth0Id: "auth0|current-tutor" } }),
    );
    expect(mocks.getTutorHourSummary).toHaveBeenCalledWith(
      {},
      7,
      expect.any(Date),
    );

    mocks.profileFindUnique.mockResolvedValueOnce({
      id: 7,
      role: "TUTOR",
      allocations: [],
    });
    mocks.getTutorHourSummary.mockResolvedValueOnce(null);
    await expect(
      dependencies.getTutorDashboard("auth0|current-tutor"),
    ).resolves.toEqual({
      allocations: [],
      weeklyLimit: null,
      usedHours: 0,
      remainingHours: null,
    });
  });

  it("persists own-tutor availability, work logs and excuses", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.timeSlotCreate.mockResolvedValueOnce({
      id: 8,
      type: "BUSY",
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2030-09-04T16:00:00.000Z"),
      recurrence: "WEEKLY",
    });
    await expect(
      dependencies.createTutorTimeSlot("auth0|current-tutor", {
        type: "BUSY",
        startsAt: new Date("2030-09-04T14:00:00.000Z"),
        endsAt: new Date("2030-09-04T16:00:00.000Z"),
        recurrence: "WEEKLY",
      }),
    ).resolves.toMatchObject({ id: 8, recurrence: "WEEKLY" });
    expect(mocks.timeSlotCreate.mock.calls[0]![0].data.tutorId).toBe(7);

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({
      id: 4,
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2020-09-04T17:00:00.000Z"),
      status: "CONFIRMED",
    });
    mocks.timesheetUpsert.mockResolvedValueOnce({ id: 3, status: "DRAFT" });
    mocks.workLogCreate.mockResolvedValueOnce({
      id: 9,
      allocationId: 4,
      timesheetId: 3,
      workDate: new Date("2030-09-04T00:00:00.000Z"),
      hours: "2.00",
      description: "Tutorial session",
    });
    await expect(
      dependencies.createTutorWorkLog("auth0|current-tutor", {
        allocationId: 4,
        workDate: "2030-09-04",
        hours: 2,
        description: "Tutorial session",
      }),
    ).resolves.toEqual({
      id: 9,
      allocationId: 4,
      timesheetId: 3,
      workDate: "2030-09-04",
      hours: 2,
      description: "Tutorial session",
    });
    expect(mocks.timesheetUpsert).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          tutorId_weekStart: { tutorId: 7, weekStart: expect.any(Date) },
        },
      }),
    );

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({ id: 4 });
    mocks.excuseCreate.mockResolvedValueOnce({
      id: 10,
      allocationId: 4,
      reason: "Sick",
      status: "PENDING",
    });
    await expect(
      dependencies.createTutorExcuse("auth0|current-tutor", {
        allocationId: 4,
        reason: "Sick",
      }),
    ).resolves.toEqual({
      id: 10,
      allocationId: 4,
      reason: "Sick",
      status: "PENDING",
    });
    expect(mocks.excuseCreate.mock.calls[0]![0].data).toMatchObject({
      tutorId: 7,
      allocationId: 4,
    });
  });

  it("hides cross-tutor sessions and maps tutor workflow conflicts", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce(null);
    await expect(
      dependencies.createTutorWorkLog("auth0|current-tutor", {
        allocationId: 999,
        workDate: "2030-09-04",
        hours: 2,
        description: "Other tutor session",
      }),
    ).rejects.toMatchObject({ status: 404, code: "ALLOCATION_NOT_FOUND" });

    mocks.profileFindUnique.mockResolvedValueOnce({
      id: 1,
      role: "ORGANISER",
    });
    await expect(
      dependencies.createTutorTimeSlot("auth0|not-a-tutor", {
        type: "BUSY",
        startsAt: new Date("2030-09-04T14:00:00.000Z"),
        endsAt: new Date("2030-09-04T16:00:00.000Z"),
      }),
    ).rejects.toMatchObject({
      status: 404,
      code: "TUTOR_PROFILE_NOT_FOUND",
    });

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({
      id: 4,
      startsAt: new Date("2030-09-05T14:00:00.000Z"),
      status: "CONFIRMED",
    });
    await expect(
      dependencies.createTutorWorkLog("auth0|current-tutor", {
        allocationId: 4,
        workDate: "2030-09-04",
        hours: 2,
        description: "Wrong date",
      }),
    ).rejects.toMatchObject({ status: 409, code: "WORK_LOG_CONFLICT" });

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({
      id: 4,
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2030-09-04T17:00:00.000Z"),
      status: "CONFIRMED",
    });
    await expect(
      dependencies.createTutorWorkLog("auth0|current-tutor", {
        allocationId: 4,
        workDate: "2030-09-04",
        hours: 2,
        description: "Session still running",
      }),
    ).rejects.toMatchObject({ status: 400, code: "SESSION_NOT_ENDED" });

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({
      id: 4,
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2020-09-04T17:00:00.000Z"),
      status: "CONFIRMED",
    });
    mocks.timesheetUpsert.mockResolvedValueOnce({
      id: 3,
      status: "SUBMITTED",
    });
    await expect(
      dependencies.createTutorWorkLog("auth0|current-tutor", {
        allocationId: 4,
        workDate: "2030-09-04",
        hours: 2,
        description: "Locked sheet",
      }),
    ).rejects.toMatchObject({ status: 409, code: "TIMESHEET_LOCKED" });

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({
      id: 4,
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2020-09-04T17:00:00.000Z"),
      status: "CONFIRMED",
    });
    mocks.timesheetUpsert.mockResolvedValueOnce({ id: 3, status: "DRAFT" });
    mocks.workLogCreate.mockRejectedValueOnce({ code: "P2002" });
    await expect(
      dependencies.createTutorWorkLog("auth0|current-tutor", {
        allocationId: 4,
        workDate: "2030-09-04",
        hours: 2,
        description: "Duplicate",
      }),
    ).rejects.toMatchObject({ status: 409, code: "WORK_LOG_DUPLICATE" });

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.timeSlotCreate.mockRejectedValueOnce({ code: "P2004" });
    await expect(
      dependencies.createTutorTimeSlot("auth0|current-tutor", {
        type: "BUSY",
        startsAt: new Date("2030-09-04T14:00:00.000Z"),
        endsAt: new Date("2030-09-04T16:00:00.000Z"),
      }),
    ).rejects.toMatchObject({ status: 409, code: "TIME_SLOT_CONFLICT" });

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({ id: 4 });
    mocks.excuseCreate.mockRejectedValueOnce({ code: "P2002" });
    await expect(
      dependencies.createTutorExcuse("auth0|current-tutor", {
        allocationId: 4,
        reason: "Duplicate",
      }),
    ).rejects.toMatchObject({ status: 409, code: "EXCUSE_DUPLICATE" });

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce(null);
    await expect(
      dependencies.createTutorExcuse("auth0|current-tutor", {
        allocationId: 999,
        reason: "Other tutor session",
      }),
    ).rejects.toMatchObject({ status: 404, code: "ALLOCATION_NOT_FOUND" });
  });

  it("scopes allocation lookups to the requesting tutor so identifiers cannot cross users", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({
      id: 4,
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2020-09-04T17:00:00.000Z"),
      status: "CONFIRMED",
    });
    mocks.timesheetUpsert.mockResolvedValueOnce({ id: 3, status: "DRAFT" });
    mocks.workLogCreate.mockResolvedValueOnce({
      id: 9,
      allocationId: 4,
      timesheetId: 3,
      workDate: new Date("2030-09-04T00:00:00.000Z"),
      hours: "2.00",
      description: "Tutorial session",
    });

    await dependencies.createTutorWorkLog("auth0|current-tutor", {
      allocationId: 4,
      workDate: "2030-09-04",
      hours: 2,
      description: "Tutorial session",
    });

    expect(mocks.allocationFindFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ id: 4, tutorId: 7 }),
      }),
    );

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({ id: 4 });
    mocks.excuseCreate.mockResolvedValueOnce({
      id: 11,
      allocationId: 4,
      reason: "Sick",
      status: "PENDING",
    });

    await dependencies.createTutorExcuse("auth0|current-tutor", {
      allocationId: 4,
      reason: "Sick",
    });

    expect(mocks.allocationFindFirst).toHaveBeenLastCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          id: 4,
          tutorId: 7,
          status: "CONFIRMED",
        }),
      }),
    );
  });

  it("maps expected Prisma conflicts to safe route errors", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();

    mocks.courseCreate.mockRejectedValueOnce({ code: "P2002" });
    await expect(
      dependencies.createCourse({ code: "DUP101", name: "Duplicate" }),
    ).rejects.toMatchObject({ status: 409, code: "COURSE_CODE_CONFLICT" });

    mocks.courseUpdate.mockRejectedValueOnce({ code: "P2025" });
    await expect(
      dependencies.updateCourse(999, { code: "NONE", name: "Missing" }),
    ).rejects.toMatchObject({ status: 404, code: "COURSE_NOT_FOUND" });
    mocks.courseUpdate.mockRejectedValueOnce({ code: "P2002" });
    await expect(
      dependencies.updateCourse(1, { code: "DUP101", name: "Duplicate" }),
    ).rejects.toMatchObject({ status: 409, code: "COURSE_CODE_CONFLICT" });

    const deleteConflict = Object.assign(new Error("blocked"), {
      status: 409,
      code: "COURSE_DELETE_CONFLICT",
    });
    mocks.courseServiceDelete.mockRejectedValueOnce(deleteConflict);
    await expect(dependencies.deleteCourse(1)).rejects.toBe(deleteConflict);
  });

  it("delegates allocation candidate queries to the Member 6 allocation engine", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();
    const candidates = [
      {
        tutorId: 1,
        fullName: "Eligible Tutor",
        mark: 80,
        weeklyLimit: 8,
        usedHours: 2,
        remainingHours: 6,
        hasClash: false,
        isEligible: true,
        reasonCodes: [],
      },
    ];
    mocks.findAllocationCandidates.mockResolvedValueOnce(candidates);
    const input = {
      courseId: 3,
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2030-09-04T16:00:00.000Z"),
      minimumMark: 50,
      requestedHours: 2,
    };

    await expect(dependencies.listAllocationCandidates(input)).resolves.toEqual(
      candidates,
    );
    expect(mocks.findAllocationCandidates).toHaveBeenCalledWith({}, input);
  });

  it("upserts tutor marks and maps missing tutor or course references", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();

    mocks.profileFindUnique.mockResolvedValueOnce({ role: "TUTOR" });
    mocks.tutorMarkUpsert.mockResolvedValueOnce({
      id: 11,
      courseId: 3,
      course: { code: "DEMO101", name: "Demo Course" },
      mark: "75.00",
    });
    mocks.allocationCount.mockResolvedValueOnce(2);
    await expect(
      dependencies.upsertTutorMark(7, { courseId: 3, mark: 75 }),
    ).resolves.toEqual({
      id: 11,
      courseId: 3,
      courseCode: "DEMO101",
      courseName: "Demo Course",
      mark: 75,
      activeAllocationCount: 2,
    });
    expect(mocks.tutorMarkUpsert.mock.calls[0]![0]).toMatchObject({
      where: { tutorId_courseId: { tutorId: 7, courseId: 3 } },
      create: { tutorId: 7, courseId: 3, mark: 75 },
      update: { mark: 75 },
    });

    mocks.profileFindUnique.mockResolvedValueOnce({ role: "ORGANISER" });
    await expect(
      dependencies.upsertTutorMark(1, { courseId: 3, mark: 75 }),
    ).rejects.toMatchObject({ status: 404, code: "TUTOR_NOT_FOUND" });

    mocks.profileFindUnique.mockResolvedValueOnce({ role: "TUTOR" });
    mocks.tutorMarkUpsert.mockRejectedValueOnce({ code: "P2003" });
    await expect(
      dependencies.upsertTutorMark(7, { courseId: 999, mark: 75 }),
    ).rejects.toMatchObject({ status: 404, code: "COURSE_NOT_FOUND" });

    mocks.profileFindUnique.mockResolvedValueOnce({ role: "TUTOR" });
    mocks.tutorMarkUpsert.mockRejectedValueOnce({ code: "P2025" });
    await expect(
      dependencies.upsertTutorMark(7, { courseId: 999, mark: 75 }),
    ).rejects.toMatchObject({ status: 404, code: "COURSE_NOT_FOUND" });
  });

  it("lists tutor marks as safe summaries ordered by course code", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();
    mocks.tutorMarkFindMany.mockResolvedValueOnce([
      {
        id: 11,
        courseId: 3,
        course: { code: "DEMO101", name: "Demo Course" },
        mark: "75.00",
      },
      {
        id: 12,
        courseId: 4,
        course: { code: "DEMO102", name: "Other Course" },
        mark: "60.50",
      },
    ]);
    mocks.allocationGroupBy.mockResolvedValueOnce([
      { courseId: 3, _count: { _all: 2 } },
    ]);

    await expect(dependencies.listTutorMarks(7)).resolves.toEqual([
      {
        id: 11,
        courseId: 3,
        courseCode: "DEMO101",
        courseName: "Demo Course",
        mark: 75,
        activeAllocationCount: 2,
      },
      {
        id: 12,
        courseId: 4,
        courseCode: "DEMO102",
        courseName: "Other Course",
        mark: 60.5,
        activeAllocationCount: 0,
      },
    ]);
    expect(mocks.tutorMarkFindMany).toHaveBeenCalledWith(
      expect.objectContaining({ where: { tutorId: 7 } }),
    );
  });

  it.each(["WEEKLY", "FORTNIGHTLY", "ONCE", null])("serializes selected tutor schedules with %s and nullable optional fields", async (recurrence) => {
    await import("./server.js");
    const dependencies = capturedDependencies();
    mocks.timeSlotFindMany.mockImplementation(async ({ where }) => where.tutorId === 7 ? [{
      id: 15, type: "BUSY", startsAt: new Date("2026-09-17T06:00:00Z"), endsAt: new Date("2026-09-17T07:45:00Z"),
      recurrence, label: null, recurrenceUntil: null, category: "CLASS", seriesId: "class-series",
    }] : []);
    await expect(dependencies.listTutorTimeSlots(7)).resolves.toEqual([{
      id: 15, type: "BUSY", startsAt: "2026-09-17T06:00:00.000Z", endsAt: "2026-09-17T07:45:00.000Z",
      recurrence, label: null, recurrenceUntil: null, category: "CLASS", seriesId: "class-series",
      termId: null, teachingBreaks: [], exceptions: [],
    }]);
    await expect(dependencies.listTutorTimeSlots(8)).resolves.toEqual([]);
    expect(mocks.timeSlotFindMany).toHaveBeenCalledWith(expect.objectContaining({ where: { tutorId: 7 }, select: expect.objectContaining({ label: true, recurrenceUntil: true }) }));
    expect(mocks.profileFindUnique).not.toHaveBeenCalled();
  });

  it("isolates marks by internal tutor ID without email or Auth0 matching", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();
    mocks.tutorMarkFindMany.mockImplementation(async ({ where }) => where.tutorId === 7
      ? [{ id: 41, courseId: 3, course: { code: "COMS3010A", name: "Computer Science" }, mark: "90.00" }] : []);
    mocks.allocationGroupBy.mockResolvedValue([]);
    await expect(dependencies.listTutorMarks(7)).resolves.toMatchObject([{ courseCode: "COMS3010A", mark: 90 }]);
    await expect(dependencies.listTutorMarks(8)).resolves.toEqual([]);
    expect(mocks.tutorMarkFindMany).toHaveBeenNthCalledWith(2, expect.objectContaining({ where: { tutorId: 8 } }));
    expect(mocks.profileFindUnique).not.toHaveBeenCalled();
    expect(mocks.timeSlotFindMany).not.toHaveBeenCalled();
  });

  it("removes organiser-managed marks with tutor scoping", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();
    mocks.tutorMarkDeleteMany.mockResolvedValueOnce({ count: 1 });

    await expect(dependencies.deleteTutorMark(7, 3)).resolves.toBeUndefined();
    expect(mocks.tutorMarkDeleteMany).toHaveBeenCalledWith({
      where: { tutorId: 7, courseId: 3 },
    });

    mocks.tutorMarkDeleteMany.mockResolvedValueOnce({ count: 0 });
    await expect(dependencies.deleteTutorMark(7, 404)).rejects.toMatchObject({
      status: 404,
      code: "TUTOR_MARK_NOT_FOUND",
    });
  });

  it("does not hide unexpected persistence failures", async () => {
    await import("./server.js");
    const dependencies = capturedDependencies();
    const unexpected = new Error("database unavailable");

    mocks.courseCreate.mockRejectedValueOnce(unexpected);
    await expect(
      dependencies.createCourse({ code: "ERR101", name: "Failure" }),
    ).rejects.toBe(unexpected);

    mocks.courseUpdate.mockRejectedValueOnce(unexpected);
    await expect(
      dependencies.updateCourse(1, { code: "ERR101", name: "Failure" }),
    ).rejects.toBe(unexpected);

    mocks.courseServiceDelete.mockRejectedValueOnce(unexpected);
    await expect(dependencies.deleteCourse(1)).rejects.toBe(unexpected);

    mocks.profileFindUnique.mockResolvedValueOnce({ role: "TUTOR" });
    mocks.tutorMarkUpsert.mockRejectedValueOnce(unexpected);
    await expect(
      dependencies.upsertTutorMark(7, { courseId: 3, mark: 75 }),
    ).rejects.toBe(unexpected);

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.timeSlotCreate.mockRejectedValueOnce(unexpected);
    await expect(
      dependencies.createTutorTimeSlot("auth0|tutor", {
        type: "BUSY",
        startsAt: new Date("2030-09-04T14:00:00.000Z"),
        endsAt: new Date("2030-09-04T16:00:00.000Z"),
      }),
    ).rejects.toBe(unexpected);

    mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: "TUTOR" });
    mocks.allocationFindFirst.mockResolvedValueOnce({
      id: 4,
      status: "CONFIRMED",
      startsAt: new Date("2030-09-04T14:00:00.000Z"),
      endsAt: new Date("2020-09-04T17:00:00.000Z"),
    });
    mocks.transaction.mockRejectedValueOnce({ code: "P2004" });
    await expect(
      dependencies.createTutorWorkLog("auth0|tutor", {
        allocationId: 4,
        workDate: "2030-09-04",
        hours: 2,
        description: "Tutoring session",
      }),
    ).rejects.toMatchObject({ status: 409, code: "WORK_LOG_CONFLICT" });
  });
});

it.each(['create', 'update'] as const)('persists class metadata and fortnightly recurrence on %s', async (operation) => {
  await import('./server.js');
  const dependencies = capturedDependencies();
  mocks.profileFindUnique.mockResolvedValueOnce({ id: 7, role: 'TUTOR' });
  const input = {
    type: 'BUSY' as const, startsAt: new Date('2030-09-04T14:00:00Z'), endsAt: new Date('2030-09-04T16:00:00Z'),
    recurrence: 'FORTNIGHTLY' as const, category: 'CLASS', seriesId: 'class-series', label: 'Lab', recurrenceUntil: null,
  };
  const write = operation === 'create' ? mocks.timeSlotCreate : mocks.timeSlotUpdate;
  write.mockResolvedValueOnce({ id: 8, ...input });
  const result = operation === 'create'
    ? await dependencies.createTutorTimeSlot('auth0|current-tutor', input)
    : await dependencies.updateTutorTimeSlot('auth0|current-tutor', 8, input);
  expect(result).toMatchObject({ recurrence: 'FORTNIGHTLY', category: 'CLASS', seriesId: 'class-series' });
  expect(write.mock.calls[0]![0].data).toMatchObject(input);
  if (operation === 'update') expect(write.mock.calls[0]![0].where).toEqual({ id: 8, tutorId: 7 });
});

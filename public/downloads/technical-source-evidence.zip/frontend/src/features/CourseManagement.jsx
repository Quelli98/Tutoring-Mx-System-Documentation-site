import { useCallback, useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useAuth0 } from '@auth0/auth0-react'
import { createCourse, deleteCourse, listCourses, updateCourse } from '../api/organiser'
import { EmptyState, ErrorState, LoadingState } from '../components/shared/StatusMessage'
import { ConfirmationDialog } from '../components/shared/ConfirmationDialog'
import { OrganiserIcon } from '../components/organiser/OrganiserIcon'
import { coverPhotoFor } from '../components/organiser/coverPhotos'

const MAX_CODE_LENGTH = 50
const MAX_NAME_LENGTH = 120

const EMPTY_FORM = { code: '', name: '', hourlyRate: '', budget: '' }

function safeErrorMessage(error, fallback) {
  if (error?.code === 'PROFILE_NOT_FOUND') {
    return 'We could not find your organiser profile. Ask an administrator to check your account.'
  }

  if (error?.code === 'ROLE_MISMATCH') {
    return 'Your account does not have organiser access.'
  }

  if (error?.code === 'VALIDATION_ERROR') {
    // The server explains exactly which value it refused, in wording already
    // safe to show.
    return error?.message || 'Check the course details and try again.'
  }

  if (error?.code === 'COURSE_DELETE_CONFLICT') {
    // The backend supplies a specific, already-safe explanation of which
    // auditable records blocked the delete; fall back to a general message.
    return (
      error?.message ||
      'This course still has historical work that must remain auditable, so it cannot be deleted. Cancel or reassign that work first.'
    )
  }

  if (error?.code === 'COURSE_CONFLICT') {
    return 'This course still has tutors, allocations or timesheets linked to it. Remove those first, then delete the course.'
  }

  return fallback
}

/**
 * Shape checks only: the text fields are filled in and a money field, if filled
 * in at all, is a number. What counts as a valid rate or budget - above zero,
 * zero or more, two decimal places - is the server's rule, and its answer is
 * shown as-is.
 */
function validateCourse({ code, name, hourlyRate, budget }) {
  const errors = {}
  const trimmedCode = code.trim()
  const trimmedName = name.trim()

  if (!trimmedCode) {
    errors.code = 'Enter a course code.'
  } else if (trimmedCode.length > MAX_CODE_LENGTH) {
    errors.code = `Use ${MAX_CODE_LENGTH} characters or fewer for the course code.`
  }

  if (!trimmedName) {
    errors.name = 'Enter a course name.'
  } else if (trimmedName.length > MAX_NAME_LENGTH) {
    errors.name = `Use ${MAX_NAME_LENGTH} characters or fewer for the course name.`
  }

  if (hourlyRate.trim() && !Number.isFinite(Number(hourlyRate))) {
    errors.hourlyRate = 'Enter the hourly rate as a number, or leave it blank.'
  }

  if (budget.trim() && !Number.isFinite(Number(budget))) {
    errors.budget = 'Enter the budget as a number, or leave it blank.'
  }

  return errors
}

// Blank clears the stored value; anything else is sent for the server to judge.
function moneyValue(text) {
  return text.trim() ? Number(text) : null
}

// Plain and the same everywhere, rather than a locale format that would read
// differently on each organiser's machine.
const CARD_ACCENTS = ['blue', 'pink', 'orchid', 'coral']

function moneyText(value) {
  return value === null || value === undefined ? 'Not set' : `R${value.toFixed(2)}`
}

function moneyFieldValue(value) {
  return value === null || value === undefined ? '' : String(value)
}

export default function CourseManagement() {
  const { getAccessTokenSilently } = useAuth0()
  const { courseId } = useParams()
  const [status, setStatus] = useState('loading')
  const [courses, setCourses] = useState([])
  const [errorMessage, setErrorMessage] = useState('')

  const [form, setForm] = useState(EMPTY_FORM)
  const [editingCourse, setEditingCourse] = useState(null)
  const [fieldErrors, setFieldErrors] = useState({})
  const [formStatus, setFormStatus] = useState('idle')
  const [formError, setFormError] = useState('')
  const [successMessage, setSuccessMessage] = useState('')

  const [courseToDelete, setCourseToDelete] = useState(null)
  const [deleteStatus, setDeleteStatus] = useState('idle')

  const loadCourses = useCallback(
    async (isActive = () => true) => {
      setStatus('loading')
      setErrorMessage('')

      try {
        const result = await listCourses(getAccessTokenSilently)
        if (!isActive()) return

        setCourses(result)
        setStatus('success')
      } catch (err) {
        if (!isActive()) return

        setCourses([])
        setErrorMessage(safeErrorMessage(err, 'Courses could not be loaded safely.'))
        setStatus('error')
      }
    },
    [getAccessTokenSilently],
  )

  useEffect(() => {
    let active = true
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadCourses(() => active)
    return () => {
      active = false
    }
  }, [loadCourses])

  function updateField(field, value) {
    setForm((current) => ({ ...current, [field]: value }))
  }

  function resetForm() {
    setForm(EMPTY_FORM)
    setEditingCourse(null)
    setFieldErrors({})
    setFormError('')
  }

  const startEditing = useCallback((course) => {
    setEditingCourse(course)
    setForm({
      code: course.code,
      name: course.name,
      hourlyRate: moneyFieldValue(course.hourlyRate),
      budget: moneyFieldValue(course.budget),
    })
    setFieldErrors({})
    setFormError('')
    setSuccessMessage('')
  }, [])

  // A link from the command centre names the course it was about. This screen is
  // what carries a course's details, so its form opens on that course once the
  // list has arrived, and only once, so cancelling the edit leaves it cancelled.
  const deepLinkOpened = useRef(false)
  useEffect(() => {
    if (deepLinkOpened.current || !courseId || status !== 'success') return
    const match = courses.find((course) => String(course.id) === String(courseId))
    if (!match) return
    deepLinkOpened.current = true
    // eslint-disable-next-line react-hooks/set-state-in-effect
    startEditing(match)
  }, [courseId, courses, startEditing, status])

  async function handleSubmit(event) {
    event.preventDefault()

    const errors = validateCourse(form)
    setFieldErrors(errors)
    setFormError('')
    setSuccessMessage('')
    if (Object.keys(errors).length > 0) return

    const payload = {
      code: form.code.trim(),
      name: form.name.trim(),
      hourlyRate: moneyValue(form.hourlyRate),
      budget: moneyValue(form.budget),
    }
    setFormStatus('saving')

    try {
      if (editingCourse) {
        await updateCourse({ courseId: editingCourse.id, ...payload }, getAccessTokenSilently)
        setSuccessMessage(`${payload.code} was updated.`)
      } else {
        await createCourse(payload, getAccessTokenSilently)
        setSuccessMessage(`${payload.code} was added.`)
      }

      resetForm()
      await loadCourses()
    } catch (err) {
      if (err?.code === 'COURSE_CODE_CONFLICT') {
        setFieldErrors({ code: 'That course code is already in use.' })
      } else {
        setFormError(safeErrorMessage(err, 'The course could not be saved safely.'))
      }
    } finally {
      setFormStatus('idle')
    }
  }

  function handleCancelDelete() {
    if (deleteStatus === 'pending') return
    setCourseToDelete(null)
  }

  async function handleConfirmDelete() {
    if (!courseToDelete || deleteStatus === 'pending') return

    setDeleteStatus('pending')
    setFormError('')
    setSuccessMessage('')

    try {
      await deleteCourse({ courseId: courseToDelete.id }, getAccessTokenSilently)
      setSuccessMessage(`${courseToDelete.code} was deleted.`)
      setCourseToDelete(null)
      await loadCourses()
    } catch (err) {
      setFormError(safeErrorMessage(err, 'The course could not be deleted safely.'))
      setCourseToDelete(null)
    } finally {
      setDeleteStatus('idle')
    }
  }

  const isSaving = formStatus === 'saving'

  return (
    <main id="main-content" className="dashboard-shell">
      <header className="dashboard-header">
        <div>
          <p className="eyebrow">Organiser workspace</p>
          <h1>Course management</h1>
          <p className="helper-text">Create and maintain the courses used across CSAM Tutor Hub.</p>
        </div>
      </header>

      <div className="course-layout">
        <section className="role-card course-form-card" aria-labelledby="course-form-heading">
          <form onSubmit={handleSubmit} noValidate>
            <h2 id="course-form-heading" className="card-title">
              <span className="card-title-icon accent-magenta">
                <OrganiserIcon name={editingCourse ? 'pencil' : 'plus'} size={18} />
              </span>
              {editingCourse ? `Edit ${editingCourse.code}` : 'Add a course'}
            </h2>

            <div className="field-group">
              <label htmlFor="course-code">Course code</label>
              <input
                id="course-code"
                type="text"
                value={form.code}
                onChange={(event) => updateField('code', event.target.value)}
                aria-invalid={Boolean(fieldErrors.code)}
                aria-describedby={fieldErrors.code ? 'course-code-error' : undefined}
              />
              {fieldErrors.code && (
                <p id="course-code-error" className="error-text">
                  {fieldErrors.code}
                </p>
              )}
            </div>

            <div className="field-group">
              <label htmlFor="course-name">Course name</label>
              <input
                id="course-name"
                type="text"
                value={form.name}
                onChange={(event) => updateField('name', event.target.value)}
                aria-invalid={Boolean(fieldErrors.name)}
                aria-describedby={fieldErrors.name ? 'course-name-error' : undefined}
              />
              {fieldErrors.name && (
                <p id="course-name-error" className="error-text">
                  {fieldErrors.name}
                </p>
              )}
            </div>

            <div className="field-group">
              <label htmlFor="course-rate">Hourly rate</label>
              <input
                id="course-rate"
                type="number"
                min="0"
                step="0.01"
                value={form.hourlyRate}
                onChange={(event) => updateField('hourlyRate', event.target.value)}
                aria-invalid={Boolean(fieldErrors.hourlyRate)}
                aria-describedby={
                  fieldErrors.hourlyRate ? 'course-rate-error' : 'course-rate-hint'
                }
              />
              <p id="course-rate-hint" className="helper-text">
                What one tutor hour costs on this course. Leave blank if there is no rate yet.
              </p>
              {fieldErrors.hourlyRate && (
                <p id="course-rate-error" className="error-text">
                  {fieldErrors.hourlyRate}
                </p>
              )}
            </div>

            <div className="field-group">
              <label htmlFor="course-budget">Budget</label>
              <input
                id="course-budget"
                type="number"
                min="0"
                step="0.01"
                value={form.budget}
                onChange={(event) => updateField('budget', event.target.value)}
                aria-invalid={Boolean(fieldErrors.budget)}
                aria-describedby={
                  fieldErrors.budget ? 'course-budget-error' : 'course-budget-hint'
                }
              />
              <p id="course-budget-hint" className="helper-text">
                What this course has to spend on tutoring. Leave blank if there is no budget yet.
              </p>
              {fieldErrors.budget && (
                <p id="course-budget-error" className="error-text">
                  {fieldErrors.budget}
                </p>
              )}
            </div>

            <div className="button-row">
              <button className="primary-button" type="submit" disabled={isSaving}>
                {isSaving ? 'Saving...' : editingCourse ? 'Save changes' : 'Add course'}
              </button>

              {editingCourse && (
                <button
                  className="secondary-button"
                  type="button"
                  onClick={resetForm}
                  disabled={isSaving}
                >
                  Cancel edit
                </button>
              )}
            </div>

            {formError && (
              <p className="status-note danger" role="alert">
                {formError}
              </p>
            )}
          </form>
        </section>

        <div className="course-list-column">
          {successMessage && (
            <p className="status-note" role="status">
              {successMessage}
            </p>
          )}

          {status === 'loading' && (
            <LoadingState
              title="Loading courses..."
              message="Please wait while we load the course list."
            />
          )}

          {status === 'error' && (
            <ErrorState
              title="Courses unavailable"
              message={errorMessage}
              onRetry={() => loadCourses()}
            />
          )}

          {status === 'success' && courses.length === 0 && (
            <EmptyState
              title="No courses yet"
              message="No courses have been set up for CSAM Tutor Hub yet."
            />
          )}

          {status === 'success' && courses.length > 0 && (
            <section className="role-card course-list-card" aria-labelledby="course-list-heading">
              <div className="course-list-heading">
                <h2 id="course-list-heading" className="card-title">
                  <span className="card-title-icon accent-violet">
                    <OrganiserIcon name="book-open" size={18} />
                  </span>
                  Courses
                </h2>
                <span className="count-chip">
                  {courses.length} {courses.length === 1 ? 'course' : 'courses'}
                </span>
              </div>
              <ul className="course-tiles" aria-label="Courses currently set up for CSAM Tutor Hub">
                {courses.map((course, index) => (
                  <li className={`course-tile accent-${CARD_ACCENTS[index % CARD_ACCENTS.length]}`} key={course.id}>
                    <div className="course-tile-cover" style={{ backgroundImage: `url(${coverPhotoFor(course, index)})` }}>
                      <span className="course-code-chip">{course.code}</span>
                      <div className="course-tile-actions">
                        <button
                          className="round-icon-button"
                          type="button"
                          onClick={() => startEditing(course)}
                          aria-label={`Edit ${course.code}`}
                          title="Edit"
                        >
                          <OrganiserIcon name="pencil" size={16} />
                        </button>
                        <button
                          className="round-icon-button danger"
                          type="button"
                          onClick={() => setCourseToDelete(course)}
                          aria-label={`Delete ${course.code}`}
                          title="Delete"
                        >
                          <OrganiserIcon name="trash" size={16} />
                        </button>
                      </div>
                    </div>
                    <div className="course-tile-body">
                      <h3>{course.name}</h3>
                      <dl className="course-tile-facts">
                        <div className="fact-rate">
                          <dt>Hourly rate</dt>
                          <dd className={course.hourlyRate === null ? 'not-set' : undefined}>{moneyText(course.hourlyRate)}</dd>
                        </div>
                        <div className="fact-budget">
                          <dt>Budget</dt>
                          <dd className={course.budget === null ? 'not-set' : undefined}>{moneyText(course.budget)}</dd>
                        </div>
                      </dl>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      </div>

      <ConfirmationDialog
        open={Boolean(courseToDelete)}
        title="Delete course"
        confirmLabel="Delete course"
        onConfirm={handleConfirmDelete}
        onCancel={handleCancelDelete}
        isPending={deleteStatus === 'pending'}
      >
        <p>
          Are you sure you want to delete{' '}
          {courseToDelete ? `${courseToDelete.code} - ${courseToDelete.name}` : 'this course'}? This
          cannot be undone.
        </p>
      </ConfirmationDialog>
    </main>
  )
}

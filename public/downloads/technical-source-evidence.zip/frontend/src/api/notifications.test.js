import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  fetchAllNotifications,
  fetchNotifications,
  fetchUnreadCount,
  markAllNotificationsRead,
  markNotificationRead,
  parseNotificationListResponse,
} from './notifications'

const VALID_ITEM = {
  id: 1,
  type: 'EXCUSE_SUBMITTED',
  title: 'Excuse awaiting decision',
  body: 'A submitted excuse is ready for an organiser decision.',
  linkPath: '/organiser',
  targetType: 'excuse',
  targetId: 10,
  readAt: null,
  createdAt: '2026-09-20T00:00:00.000Z',
}

function okResponse(body) {
  return { ok: true, status: 200, json: async () => body }
}

afterEach(() => {
  vi.restoreAllMocks()
})

describe('parseNotificationListResponse', () => {
  it('accepts a well-formed list payload', () => {
    const result = parseNotificationListResponse({
      data: { items: [VALID_ITEM], page: 1, pageSize: 10, total: 1, unreadCount: 1 },
    })
    expect(result.items).toHaveLength(1)
    expect(result.unreadCount).toBe(1)
  })

  it('rejects a payload whose items break the contract', () => {
    expect(() =>
      parseNotificationListResponse({
        data: { items: [{ id: 0 }], page: 1, pageSize: 10, total: 1, unreadCount: 0 },
      }),
    ).toThrow(/did not match/i)
  })

  it('rejects a payload missing the paging counters', () => {
    expect(() =>
      parseNotificationListResponse({ data: { items: [] } }),
    ).toThrow(/did not match/i)
  })
})

describe('fetchNotifications', () => {
  it('caps pageSize at 25 and defaults status to unread', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi
      .fn()
      .mockResolvedValue(
        okResponse({ data: { items: [], page: 1, pageSize: 25, total: 0, unreadCount: 0 } }),
      )

    await fetchNotifications({ pageSize: 500 }, token)

    const [url] = globalThis.fetch.mock.calls[0]
    expect(url).toContain('status=unread')
    expect(url).toContain('pageSize=25')
    expect(url).toContain('page=1')
  })

  it('passes an explicit all filter and page through', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi
      .fn()
      .mockResolvedValue(
        okResponse({ data: { items: [], page: 3, pageSize: 10, total: 0, unreadCount: 0 } }),
      )

    await fetchNotifications({ status: 'all', page: 3, pageSize: 10 }, token)

    const [url] = globalThis.fetch.mock.calls[0]
    expect(url).toContain('status=all')
    expect(url).toContain('page=3')
    expect(url).toContain('pageSize=10')
  })
})

describe('fetchAllNotifications', () => {
  function pageOfItems(ids) {
    return ids.map((id) => ({ ...VALID_ITEM, id }))
  }

  it('reads every page, so a reminder past the first page is still surfaced', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    const firstPage = pageOfItems(Array.from({ length: 25 }, (_, index) => index + 1))
    const secondPage = pageOfItems(Array.from({ length: 25 }, (_, index) => index + 26))
    const reminderBeyondFirstPage = {
      ...VALID_ITEM,
      id: 60,
      type: 'TIMESHEET_REVIEW_DUE',
      title: 'A timesheet has waited two days for review',
      targetType: 'timesheet',
      targetId: 501,
    }
    globalThis.fetch = vi
      .fn()
      .mockResolvedValueOnce(
        okResponse({ data: { items: firstPage, page: 1, pageSize: 25, total: 51, unreadCount: 3 } }),
      )
      .mockResolvedValueOnce(
        okResponse({ data: { items: secondPage, page: 2, pageSize: 25, total: 51, unreadCount: 3 } }),
      )
      .mockResolvedValueOnce(
        okResponse({
          data: { items: [reminderBeyondFirstPage], page: 3, pageSize: 25, total: 51, unreadCount: 3 },
        }),
      )

    const result = await fetchAllNotifications({ status: 'all' }, token)

    expect(result.items).toHaveLength(51)
    expect(result.items.at(-1)).toMatchObject({
      id: 60,
      type: 'TIMESHEET_REVIEW_DUE',
      targetType: 'timesheet',
      targetId: 501,
    })
    expect(globalThis.fetch).toHaveBeenCalledTimes(3)
    const urls = globalThis.fetch.mock.calls.map(([url]) => url)
    expect(urls[0]).toContain('status=all')
    expect(urls[1]).toContain('page=2')
    expect(urls[1]).toContain('pageSize=25')
    expect(urls[2]).toContain('page=3')
  })

  it('reads once when the reported total fits on the first page', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi
      .fn()
      .mockResolvedValue(
        okResponse({ data: { items: [VALID_ITEM], page: 1, pageSize: 25, total: 1, unreadCount: 1 } }),
      )

    const result = await fetchAllNotifications({ status: 'all' }, token)

    expect(result.items).toHaveLength(1)
    expect(globalThis.fetch).toHaveBeenCalledTimes(1)
  })

  it('stops at the total the first page reported rather than a later, larger one', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi.fn().mockImplementation((url) => {
      const page = Number(new URL(url, 'http://localhost').searchParams.get('page'))
      return okResponse({
        data: {
          items: pageOfItems(Array.from({ length: 25 }, (_, index) => (page - 1) * 25 + index + 1)),
          page,
          pageSize: 25,
          // Only the total the first page reported bounds the walk; a later
          // page claiming the store has grown cannot stretch it.
          total: page === 1 ? 50 : 100000,
          unreadCount: 0,
        },
      })
    })

    const result = await fetchAllNotifications({}, token)

    expect(globalThis.fetch).toHaveBeenCalledTimes(2)
    expect(result.items).toHaveLength(50)
  })

  it('reads past a thousand rows, so a reminder on the last page is still surfaced', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    const finalReminder = {
      ...VALID_ITEM,
      id: 1001,
      type: 'TIMESHEET_REVIEW_DUE',
      title: 'A timesheet has waited two days for review',
      targetType: 'timesheet',
      targetId: 901,
    }
    const rows = [
      ...pageOfItems(Array.from({ length: 1000 }, (_, index) => index + 1)),
      finalReminder,
    ]
    globalThis.fetch = vi.fn().mockImplementation((url) => {
      const page = Number(new URL(url, 'http://localhost').searchParams.get('page'))
      return okResponse({
        data: {
          items: rows.slice((page - 1) * 25, page * 25),
          page,
          pageSize: 25,
          total: 1001,
          unreadCount: 0,
        },
      })
    })

    const result = await fetchAllNotifications({}, token)

    expect(globalThis.fetch).toHaveBeenCalledTimes(41)
    expect(result.items).toHaveLength(1001)
    expect(result.items.at(-1)).toMatchObject({
      id: 1001,
      type: 'TIMESHEET_REVIEW_DUE',
      targetType: 'timesheet',
      targetId: 901,
    })
  })

  it('rejects when a later page fails, so the caller degrades rather than working from half the store', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi
      .fn()
      .mockResolvedValueOnce(
        okResponse({ data: { items: [VALID_ITEM], page: 1, pageSize: 1, total: 2, unreadCount: 1 } }),
      )
      .mockRejectedValueOnce(new Error('page two unavailable'))

    await expect(fetchAllNotifications({}, token)).rejects.toThrow(/page two unavailable/)
  })
})

describe('fetchUnreadCount', () => {
  it('returns the integer unread count', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi.fn().mockResolvedValue(okResponse({ data: { unreadCount: 4 } }))
    await expect(fetchUnreadCount(token)).resolves.toBe(4)
  })

  it('rejects a malformed unread count', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi.fn().mockResolvedValue(okResponse({ data: { unreadCount: -1 } }))
    await expect(fetchUnreadCount(token)).rejects.toThrow(/did not match/i)
  })
})

describe('markNotificationRead', () => {
  it('sends a PATCH for a valid id', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi
      .fn()
      .mockResolvedValue(okResponse({ data: { notification: { id: 1, readAt: 'now' } } }))

    const result = await markNotificationRead(1, token)

    expect(result).toEqual({ id: 1, readAt: 'now' })
    const [url, options] = globalThis.fetch.mock.calls[0]
    expect(url).toContain('/api/notifications/1/read')
    expect(options.method).toBe('PATCH')
  })

  it('refuses an invalid id before calling the network', async () => {
    globalThis.fetch = vi.fn()
    await expect(markNotificationRead(0, vi.fn())).rejects.toThrow(/notification id/i)
    expect(globalThis.fetch).not.toHaveBeenCalled()
  })
})

describe('markAllNotificationsRead', () => {
  it('posts and returns the updated count', async () => {
    const token = vi.fn().mockResolvedValue('token-1')
    globalThis.fetch = vi.fn().mockResolvedValue(okResponse({ data: { updated: 5 } }))

    await expect(markAllNotificationsRead(token)).resolves.toBe(5)
    const [url, options] = globalThis.fetch.mock.calls[0]
    expect(url).toContain('/api/notifications/read-all')
    expect(options.method).toBe('POST')
  })
})

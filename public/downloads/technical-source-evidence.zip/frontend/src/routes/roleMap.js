export const ROLE_ROUTE_MAP = Object.freeze({
  ORGANISER: { path: '/organiser', label: 'Organiser workspace' },
  TUTOR: { path: '/tutor', label: 'Tutor workspace' },
  STUDENT: { path: '/student', label: 'Student workspace' },
})

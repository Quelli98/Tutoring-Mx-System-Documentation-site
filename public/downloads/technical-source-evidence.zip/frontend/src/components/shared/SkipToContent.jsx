export function SkipToContent() {
  return (
    <a className="skip-to-content" href="#main-content">
      Skip to main content
    </a>
  )
}
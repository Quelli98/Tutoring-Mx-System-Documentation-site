# Frontend AI declaration

The repository-level `AI_DECLARATION.md` is authoritative for this integrated project.

Codex[GPT-5] was used on 13 September 2026 to reconcile Sprint 2 Member 4 with the current authenticated Student and public-holiday API contracts; complete persisted outcome, fallback, mobile and keyboard states; fix stable request wiring; and add frontend contract/component/integration regression tests.

Codex[GPT-5] was used on 23 August 2026 to review and complete Member 2's Sprint 1 Organiser frontend: allocation-board states, written mark/clash/hour rule results, course/tutor management integration, tutor marks and busy times, responsive styling, API-contract validation and component tests.

Codex[GPT-5] was used to integrate and review the Tutor dashboard, availability, draft work-log and excuse forms; replace simulated API functions with authenticated Express calls; add accessibility, responsive, contract and integration tests; and update the handoff documentation.

The supplied evidence confirms Qoder application version 1.23.0, VS Code version 1.106.3, Quest Agent mode and the Auto tier. Qoder automatically routed each request to an underlying model that was not disclosed, so no specific provider model has been guessed. The truthful declaration is `Qoder[Auto tier; underlying model automatically routed]`.
The preceding document was generated and reviewed with the assistance of the following: Codex[GPT-5], ChatGPT[GPT-5.6 Sol].

ChatGPT[GPT-5.6 Sol] was used on 16 August 2026 to verify integration of the deployed frontend snapshot back into the Gitea-ready project and to update deployment documentation.

ChatGPT[GPT-5.6 Sol] was used on 17 August 2026 to integrate Member 4's Student overflow, volunteer confirmation, shared status/navigation and accessibility changes into the current frontend, including the case-sensitive `studentOverflow.js` import fix and shared `main-content` targets.

- 17 Aug 2026: Self-service role onboarding (front-page role choice, server-only Auth0 Management API role provisioning, automatic Prisma/Neon Profile creation, first-token role resolution and tests) was assisted by ChatGPT [GPT-5.6 Sol].
